---
title: Generic Ajax

access:
    admin.configuration: true
    admin.super: true
---
